export type MovieTag = string;

export type Movie = {
  id: string;
  title: string;
  description: string;
  poster: string;
  video: string;
  download?: string;
  category: string;
  language: string;
  tags: MovieTag[];
  year?: number;
  runtime?: number;
  rating?: number;
  createdAt?: number;
  updatedAt?: number;
};

export type Promotion = {
  id: string;
  image: string;
  link: string;
  status: boolean;
  title?: string;
};

export type Banner = {
  id: string;
  title: string;
  description: string;
  poster: string;
  image: string;
  video: string;
  category: string;
  language: string;
  tags: MovieTag[];
  movieId?: string;
  status?: boolean;
};

export type AppSettings = {
  adsEnabled: boolean;
  lastUpdated: number;
};

export type SessionUser = {
  uid: string;
  email: string;
  name: string;
  photo?: string;
  provider: "google" | "email" | "local" | "guest";
};

export type WatchedItem = {
  id: string;
  title: string;
  poster: string;
  at: number;
};

export type PrimeflixDump = {
  movies: Record<string, Movie>;
  promotions: Record<string, Promotion>;
  banners: Record<string, Banner>;
  settings: AppSettings;
};

export const CATEGORIES = [
  "Action",
  "Adventure",
  "Drama",
  "Sci-Fi",
  "Thriller",
  "Romance",
  "Mystery",
] as const;

export const LANGUAGES = [
  "English",
  "Hindi",
  "Spanish",
  "Korean",
  "Japanese",
  "French",
] as const;

export const TAG_PRESETS = [
  "Trending",
  "New Release",
  "Award Winner",
  "Editor's Pick",
  "Limited",
] as const;
